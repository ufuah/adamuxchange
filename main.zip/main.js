// header bg reveal

const headerbg = () => {
    const header = document.querySelector('.desktop-nav');
    const navLinks = document.querySelector('.nav-links');
    
    window.addEventListener('scroll', function() {
        if (this.scrollY > 0) {
            header.classList.add('shadow');
            navLinks.classList.add('linkscolor')
        } else {
            header.classList.remove('shadow')
            navLinks.classList.remove('linkscolor')
        }
    })
    }
    
    headerbg();



const mobbileheaderbg = () => {
    const header = document.querySelector('.nav-mobile');
    const navLinks = document.querySelector('.nav-links');
    
    window.addEventListener('scroll', function() {
        if (this.scrollY > 0) {
            header.classList.add('shadow');
            navLinks.classList.add('linkscolor')
        } else {
            header.classList.remove('shadow')
            navLinks.classList.remove('linkscolor')
        }
    })
    }
    
    mobbileheaderbg();



    var icon = document.getElementById("mode");

    icon.onclick = function() {
        document.body.classList.toggle("dark-mode")
    }

    let toggleMenu = document.querySelector('.toggleMenu');
    let navigation = document.querySelector('.navigation');

    toggleMenu.onclick = function () {
        navigation.classList.toggle('active');
    }